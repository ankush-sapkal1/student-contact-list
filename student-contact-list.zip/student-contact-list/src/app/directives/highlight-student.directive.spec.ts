

import { element } from 'protractor';
import { HighlightStudentDirective } from './highlight-student.directive';

describe('HighlightStudentDirective', () => {
  
});


